from django.forms import ModelForm
from .models import Room

# this is called model from

class RoomForm(ModelForm):
    class Meta:
        model = Room
        fields = '__all__' # takes an array
        exclude = ['host' , 'participants']