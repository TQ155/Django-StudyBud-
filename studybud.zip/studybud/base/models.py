from pyexpat import model
from django.db import models
from django.contrib.auth.models import User
from django.db.models.deletion import CASCADE
# Create your models here.

class Topic(models.Model):
    name = models.CharField(max_length=200)
    def __str__(self):
        return self.name

class Room(models.Model):
    host = models.ForeignKey(User,on_delete=models.SET_NULL,null=True)
    topic = models.ForeignKey(Topic, on_delete=models.SET_NULL,null=True) 
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True) # cant be empty
    participants = models.ManyToManyField(User, related_name="participants" , blank=True)# many to many relationships 
    updated = models.DateTimeField(auto_now_add=True) # everytime it gets saved
    created = models.DateTimeField(auto_now=True) #only takes snaptime when we first create it
    
    class Meta:
        ordering = ['-created' , '-updated']
    
    def __str__(self):
        return self.name
    
class Message(models.Model):
     user = models.ForeignKey(User,on_delete=models.CASCADE)
     room = models.ForeignKey(Room, on_delete=models.CASCADE,null=True) # on_delete -> set_null, cascade
     body = models.TextField()
     updated = models.DateTimeField(auto_now_add=True) # everytime it gets saved
     created = models.DateTimeField(auto_now=True) #only takes snaptime when we first create it
     
     class Meta:
        ordering = ['-created' , '-updated']
     
     def __str__(self):
        return self.body[0:50]
    