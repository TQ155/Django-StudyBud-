from django.contrib import admin
from django.urls import path,include
from django.http import HttpResponse

# this is a simple view ! However we will be bringing the vews from views.py

"""
def home(request):
    return HttpResponse('Home Page')

def room(request):
    return HttpResponse('Room Page')
"""

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('base.urls')), 
]

